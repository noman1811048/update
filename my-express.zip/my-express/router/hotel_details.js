const express = require('express');
const router = express.Router();
const hotelController = require('../controller/hotel_details');
const upload = require('../middlewares/upload');

// Create a new hotel
router.post('/', upload.single('image'), hotelController.createHotel);

// Get all hotels with optional filtering and pagination
router.get('/', hotelController.getAllHotels);

// Get a specific hotel by slug
router.get('/:slug', hotelController.getHotelBySlug);

// Update a hotel
router.put('/:slug', upload.single('image'), hotelController.updateHotel);

// Delete a hotel
router.delete('/:slug', hotelController.deleteHotel);

module.exports = router;
