// const HotelDetails = require('../model/hotel_details');

// exports.createHotel = async (req, res) => {
//   try {
//     const hotel = await HotelDetails.create(req.body);
//     res.status(201).json(hotel);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// };

// exports.getAllHotels = async (req, res) => {
//   try {
//     const hotels = await HotelDetails.findAll();
//     res.json(hotels);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// exports.getHotelBySlug = async (req, res) => {
//   try {
//     const hotel = await HotelDetails.findOne({ where: { slug: req.params.slug } });
//     if (hotel) {
//       res.json(hotel);
//     } else {
//       res.status(404).json({ message: 'Hotel not found' });
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// exports.updateHotel = async (req, res) => {
//   try {
//     const [updated] = await HotelDetails.update(req.body, {
//       where: { slug: req.params.slug }
//     });
//     if (updated) {
//       const updatedHotel = await HotelDetails.findOne({ where: { slug: req.params.slug } });
//       res.json(updatedHotel);
//     } else {
//       res.status(404).json({ message: 'Hotel not found' });
//     }
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// };

// exports.deleteHotel = async (req, res) => {
//   try {
//     const deleted = await HotelDetails.destroy({
//       where: { slug: req.params.slug }
//     });
//     if (deleted) {
//       res.status(204).send();
//     } else {
//       res.status(404).json({ message: 'Hotel not found' });
//     }
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };


const HotelDetails = require('../model/hotel_details');

exports.createHotel = async (req, res) => {
  try {
    const hotelData = req.body;
    if (req.file) {
      const imagePath = req.file.path;
      hotelData.images = [{ path: imagePath }];
    }
    const hotel = await HotelDetails.create(hotelData);
    res.status(201).json(hotel);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.getAllHotels = async (req, res) => {
  try {
    const hotels = await HotelDetails.findAll();
    res.json(hotels);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getHotelBySlug = async (req, res) => {
  try {
    const hotel = await HotelDetails.findOne({ where: { slug: req.params.slug } });
    if (hotel) {
      res.json(hotel);
    } else {
      res.status(404).json({ message: 'Hotel not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateHotel = async (req, res) => {
  try {
    const hotelData = req.body;
    if (req.file) {
      const imagePath = req.file.path;
      hotelData.images = [{ path: imagePath }];
    }
    const [updated] = await HotelDetails.update(hotelData, {
      where: { slug: req.params.slug }
    });
    if (updated) {
      const updatedHotel = await HotelDetails.findOne({ where: { slug: req.params.slug } });
      res.json(updatedHotel);
    } else {
      res.status(404).json({ message: 'Hotel not found' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteHotel = async (req, res) => {
  try {
    const deleted = await HotelDetails.destroy({
      where: { slug: req.params.slug }
    });
    if (deleted) {
      res.status(204).send();
    } else {
      res.status(404).json({ message: 'Hotel not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
