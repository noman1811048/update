const { DataTypes } = require('sequelize');
const sequelize = require('../db'); // Import the sequelize instance

const HotelDetails = sequelize.define('HotelDetails', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  slug: {
    type: DataTypes.STRING(100),
    unique: true,
    allowNull: false,
  },
  title: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
  },
  guest_count: {
    type: DataTypes.INTEGER,
  },
  bedroom_count: {
    type: DataTypes.INTEGER,
  },
  bathroom_count: {
    type: DataTypes.INTEGER,
  },
  amenities: {
    type: DataTypes.ARRAY(DataTypes.STRING),
  },
  host_information: {
    type: DataTypes.JSONB,
  },
  address: {
    type: DataTypes.STRING(255),
  },
  latitude: {
    type: DataTypes.DECIMAL(10, 6),
  },
  longitude: {
    type: DataTypes.DECIMAL(10, 6),
  },
  images: {
    type: DataTypes.ARRAY(DataTypes.JSONB),
  },
}, {
  tableName: 'hotel_details',
  timestamps: true, // Adds createdAt and updatedAt fields
});

module.exports = HotelDetails;
