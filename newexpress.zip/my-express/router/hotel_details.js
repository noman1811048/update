const express = require('express');
const router = express.Router();
const hotelController = require('../controller/hotel_details');
const upload = require('../middlewares/upload');

// Create a new hotel
router.post('/', upload.array('images', 10), hotelController.createHotel); // Allow up to 10 images

// Get all hotels with optional filtering and pagination
router.get('/', hotelController.getAllHotels);

// Get a specific hotel by slug
router.get('/:slug', hotelController.getHotelBySlug);

// Update a hotel
router.put('/:slug', upload.array('images', 10), hotelController.updateHotel); // Allow up to 10 images

// Delete a hotel
router.delete('/:slug', hotelController.deleteHotel);

module.exports = router;
